public abstract class VIP_Card extends Card {
    String name;

    @Override
    public void display() {
        System.out.println("此卡为: "+name);
    }
}
