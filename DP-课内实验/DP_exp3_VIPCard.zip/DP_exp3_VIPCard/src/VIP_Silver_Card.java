public class VIP_Silver_Card extends VIP_Card{
    public VIP_Silver_Card(){
        this.name="会员银卡";
    }

}
