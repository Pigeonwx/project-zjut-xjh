public class VIP_Gold_Card extends VIP_Card{
    public VIP_Gold_Card(){
        this.name="会员金卡";
    }

}
