public abstract class Card {
    public abstract void display();
}
