public class CardFactory extends Factory{
    @Override
    protected Card produce(String name) {
        switch (name){
            case "gold_card":{
                return new VIP_Gold_Card();
            }
            case "silver_card":{
                return new VIP_Silver_Card();
            }
            case "common_card":{
                return new VIP_Common_Card();
            }
        }
        return null;
    }

    @Override
    public Card order(String name) {
        return produce(name);
    }
}
