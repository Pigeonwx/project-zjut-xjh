public class Client {
    String name;
    VIP_Card vip_card;
    Client(String name,VIP_Card vip_card){
        this.name=name;
        this.vip_card=vip_card;
    }
}
