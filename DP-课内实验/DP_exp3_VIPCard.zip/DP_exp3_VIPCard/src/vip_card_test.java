public class vip_card_test {
    public static void main(String[] args) {
        CardFactory cardFactory = new CardFactory();
        Client[] clients = new Client[6];
        String[] vip_cards = {"gold_card", "silver_card", "common_card"};
        for (int i = 0; i < 6; i++) {
            VIP_Card vip_card = (VIP_Card) cardFactory.order(vip_cards[i % 3]);
            System.out.println("============================================");
            System.out.println("制造第"+(i+1)+"张会员卡：");
            vip_card.display();
            clients[i] = new Client(("张" + (i+1)), vip_card);
            System.out.println("第"+(i+1)+"张会员卡制造完毕，分配给客户---"+clients[i].name);
            System.out.println("============================================");
        }
    }
}
