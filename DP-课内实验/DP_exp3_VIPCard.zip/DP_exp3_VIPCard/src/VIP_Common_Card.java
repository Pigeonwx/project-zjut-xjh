public class VIP_Common_Card extends VIP_Card{
    public VIP_Common_Card(){
        this.name="会员普通卡";
    }

}
