public abstract class Factory {
    protected abstract Card produce(String name);
    public abstract Card order(String name);
}
