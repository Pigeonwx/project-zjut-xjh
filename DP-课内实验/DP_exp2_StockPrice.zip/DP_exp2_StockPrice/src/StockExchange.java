import java.util.ArrayList;
import java.util.Random;

public class StockExchange implements Subject {
    double price;
    boolean change_flag;
    ArrayList<Observer> stockholders;

    StockExchange() {
        stockholders = new ArrayList<Observer>();
        change_flag = false;
    }

    @Override
    public void addObserver(Observer o) {
        if (!(stockholders.contains(o)))
            stockholders.add(o);
    }

    @Override
    public void removeObserver(Observer o) {
        if (stockholders.contains(o))
            stockholders.remove(o);
    }

    @Override
    public void notifyObserver(Double price) {
        if (change_flag){
            for (int i=0;i<stockholders.size();i++){
                Observer observer=stockholders.get(i);
                observer.updateObserver(price);
            }
            change_flag=false;
        }
    }

    @Override
    public double changeStockPrice() {
        final Random random=new Random();

        for (int i=0;i<10;i++){
            System.out.println("第"+(i+1)+"次价格波动：");
            change_flag =true;
            price=random.nextFloat()*100;
            notifyObserver(price);
            System.out.println("==================================================");
        }
        return price;
    }
}
