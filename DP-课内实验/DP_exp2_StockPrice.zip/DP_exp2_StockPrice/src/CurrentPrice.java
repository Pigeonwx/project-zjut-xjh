import java.awt.*;

public class CurrentPrice implements Observer, DisplayReport {
    Subject stock;
    double price;
    public CurrentPrice(Subject stock){
        this.stock=stock;
        stock.addObserver(this);
    }
    @Override
    public void display() {
        System.out.println("股票当前价格为"+price);
    }

    @Override
    public void updateObserver(double price) {
        this.price=price;
        display();
    }
}
