public interface Observer {
    public void updateObserver(double price);
}
