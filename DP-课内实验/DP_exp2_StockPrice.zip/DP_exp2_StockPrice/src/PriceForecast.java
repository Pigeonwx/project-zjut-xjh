import java.text.DecimalFormat;
import java.util.Vector;

public class PriceForecast implements Observer,DisplayReport{

    Subject stock;
    int count;
    double average, sum;
    Vector<Double> vd = new Vector<Double>();

    public PriceForecast(Subject stock) {
        count = 0;
        sum = 0;
        this.stock = stock;
        stock.addObserver(this);
    }
    @Override
    public void display() {
        System.out.println("股票价格预测:" + average + "元。");
    }

    @Override
    public void updateObserver(double price) {
        vd.add(price);
        int n = vd.size();
        //用近三天均价估计预测
        if (n == 1)
            average = price;
        else {
            if (n == 2) {
                sum = vd.get(0) + vd.get(1);
                average = sum / n;
            } else {
                sum = vd.get(n - 1) + vd.get(n - 2) + vd.get(n - 3);
                average = sum / 3;
            }
        }
        DecimalFormat df = new DecimalFormat("#.00");
        average = Double.parseDouble(df.format(average));
        display();
    }
}
