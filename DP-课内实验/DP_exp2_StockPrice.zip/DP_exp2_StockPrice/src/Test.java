public class Test {
    public static void main(String[] args) {
        //创建股票主题对象实例
        Subject stock = new StockExchange();
        //新增观察者实例
        new CurrentPrice(stock);
        new PriceStatistics(stock);
        new PriceForecast(stock);
        //股价波动
        stock.changeStockPrice();
    }
}
