import java.text.DecimalFormat;
import java.util.Vector;

public class PriceStatistics implements Observer, DisplayReport {


    Subject stock;
    int count;
    double max, min, average, sum;
    Vector<Double> vd = new Vector<Double>();// 存储股票的价格

    public PriceStatistics(Subject stock){
        sum = 0;
        count = 0;
        this.stock = stock;
        stock.addObserver(this);
    }

    @Override
    public void display() {
        System.out.println("股票价格的统计分析报告:(股票最高价:" + max + "元、股票最低价:" + min + "元、股票平均价:" + average + "元)。");
    }

    @Override
    public void updateObserver(double price) {
        vd.add(price);
        int n = vd.size();
        if (n == 1) {
            max = price;
            min = price;
        } else {
            if (max < price)
                max = price;
            if (min > price)
                min = price;
        }
        ++count;
        sum = sum + price;
        average = sum / count;
        DecimalFormat df = new DecimalFormat("#.00");
        average = Double.parseDouble(df.format(average));
        display();
    }
}
