public interface DisplayReport {
    public void display();
}
