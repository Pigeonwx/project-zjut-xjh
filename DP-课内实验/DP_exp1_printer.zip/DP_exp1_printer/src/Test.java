public class Test {
    public static void main(String[]args) {
        //折扣--1：无折扣
        No_discount no_discount=new No_discount();
        //折扣--2：固定减10元
        Fix_discount fix_discount1=new Fix_discount();
        fix_discount1.setDiscount_num(10);
        //折扣--3：固定减100元
        Fix_discount fix_discount2=new Fix_discount();
        fix_discount2.setDiscount_num(100);
        //折扣--4：打9折
        Percent_discount percent_discount1=new Percent_discount();
        percent_discount1.setDiscount_num(0.9);
        //折扣--5：打5折
        Percent_discount percent_discount2=new Percent_discount();
        percent_discount2.setDiscount_num(0.5);

        Discount[]discounts={no_discount,fix_discount1,fix_discount2,percent_discount1,percent_discount2};

        //打印机--1
        Printer_A printer_a=new Printer_A();
        //打印机--2
        Printer_B printer_b=new Printer_B();
        //打印机--3
        Printer_C printer_c=new Printer_C();

        Printer[]printers={printer_a,printer_b,printer_c};

        for (int i=0;i<discounts.length;i++){
            for(int j=0;j<printers.length;j++){
                printers[j].setDiscount(discounts[i]);
                printers[j].sale();
            }
        }
    }
}
