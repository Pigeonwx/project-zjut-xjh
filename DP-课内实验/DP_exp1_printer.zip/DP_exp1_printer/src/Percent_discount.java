public class Percent_discount implements Discount{
    private double discount_num;
    @Override
    public void discount_calculate(double price) {
        System.out.println("此次销售折扣：打"+discount_num+"折：");
        System.out.println("此次销售打印机的最终价格是： "+ price * discount_num+"元");
    }

    public void setDiscount_num(double num){
        discount_num=num;
    }
}
