public class No_discount implements Discount{
    @Override
    public void discount_calculate(double price) {
        System.out.println("此次销售没有折扣：");
        System.out.println("此次销售打印机的最终价格是： " + price+"元");
    }
}
