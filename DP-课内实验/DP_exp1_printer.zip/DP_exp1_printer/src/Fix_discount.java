public class Fix_discount implements Discount {
    private double discount_num;
    @Override
    public void discount_calculate(double price) {
        System.out.println("此次销售折扣：固定减"+discount_num+"元：");
        if (price>discount_num) {
            System.out.println("此次销售打印机的最终价格是： " + (price - discount_num)+"元");
        }
        else {
            System.out.println("此次销售打印机的最终价格是： " + 0 +"元");
        }
    }

    public void setDiscount_num(double num){
        discount_num=num;
    }
}
