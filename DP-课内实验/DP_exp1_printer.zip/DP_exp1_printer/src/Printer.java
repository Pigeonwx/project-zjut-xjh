public abstract class Printer {
    private double price;
    private Discount discount;

    public abstract void setDiscount(Discount discount);
    public abstract void sale();
}
