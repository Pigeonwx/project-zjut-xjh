public interface Discount {
    void discount_calculate(double price);
}
