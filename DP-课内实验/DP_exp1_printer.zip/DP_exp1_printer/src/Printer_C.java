public class Printer_C extends Printer{
    //打印机原价
    private double price = 1000;
    //打印机名称
    private String printer_type = "Printer_C";
    //打印机销售的折扣方式
    private Discount discount;

    public void sale() {
        System.out.println("=========开始销售============");
        System.out.println("销售打印机 类型-"+printer_type);
        System.out.println("销售打印机 原价-"+price+"元");
        discount.discount_calculate(price);
        System.out.println("=========结束销售============");
    }


    public void setPrice(double price) {
        this.price = price;
    }

    public void setDiscount(Discount discount) {
        this.discount = discount;
    }
}
