package po;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertiesUtil {
    public static int getValue(String key) {
        Properties prop = new Properties();
        try {
            //装载配置文件
            prop.load(new FileInputStream(new File("src//config//InstanceLimit.cfg")));

        } catch (IOException e) {
            e.printStackTrace();
        }
        //返回获取的值
        return Integer.parseInt(prop.getProperty(key));
    }

}