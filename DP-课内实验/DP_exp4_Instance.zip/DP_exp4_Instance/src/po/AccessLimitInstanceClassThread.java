package po;

import java.util.Random;

public class AccessLimitInstanceClassThread extends Thread {
    public synchronized void run() {
        try {

            System.out.println("==========线程开演示开始===============");
            LimitInstanceClass lc = LimitInstanceClass.getInstance();
            lc.writeAccessMessage(this.getName().toString());
            System.out.println("线程创建成功，获取到实例" + lc.id);
            Random random = new Random();
            int time = random.nextInt(5000) + 1;
            System.out.println("线程随机休眠" + time / 1000 + "秒，请稍等...");
            sleep(time);

            System.out.println("线程开始打印获取消息...");
            lc.printAccessMessage();

            LimitInstanceClass.release(lc);
            System.out.println("instance实例释放成功！");

            System.out.println("==========线程演示结束===============");
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
