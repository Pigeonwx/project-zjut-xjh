package po;


import java.io.File;
import java.io.FileReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Properties;

public class LimitInstanceClass {

    public int id;
    private boolean isBusy;
    private static final ArrayList<LimitInstanceClass> instances_pool = new ArrayList<>();
    private String accessMessage;
    private LimitInstanceClass() {}

    private static void init() {
        try {
            int num = PropertiesUtil.getValue("INSTANCE_NUM");
            for (int i = 0; i < num; i++) {
                LimitInstanceClass l = new LimitInstanceClass();
                l.id = i + 1;
                l.isBusy = false;
                instances_pool.add(l);
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public static synchronized LimitInstanceClass getInstance() {
        if (instances_pool.size() == 0)
            init();
        for (int i = 0; i < instances_pool.size(); i++) {
            LimitInstanceClass l = (LimitInstanceClass) instances_pool.get(i);
            if (l.isBusy == false) {
                l.isBusy = true;
                instances_pool.set(i, l);
                return l;
            }
        }
        return null;
    }

    public static synchronized void release(LimitInstanceClass lc) {
        if (lc.isBusy == true)
            lc.isBusy = false;
    }

    public void writeAccessMessage(String message) {
        accessMessage = message;
    }

    public void printAccessMessage() {
        System.out.println("本实例所携带的消息："+accessMessage);
    }



}
